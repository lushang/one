<?php
/**
 * 2014年最新版Google Analytics 统计 Universal Analytics
 * 
 * @package Universal Analytics
 * @author 銮尊
 * @version 1.0.0
 * @link http://www.luanzun.com/
 */
class UniversalAnalytics_Plugin implements Typecho_Plugin_Interface
{
    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     * 
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate()
    {
        Typecho_Plugin::factory('Widget_Archive')->footer = array('UniversalAnalytics_Plugin', 'render');
    }
    
    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     * 
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate(){}
    
    /**
     * 获取插件配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form)
    {
        /** 分类名称 */
        $account = new Typecho_Widget_Helper_Form_Element_Text('account', NULL, 'UA-XXXXXXX-X', _t('Universal Analytics 帐号'), _t('此帐号可在 GA 管理平台查询；格式为 UA-XXXXXXX-X 。'));
        $form->addInput($account);
		$website = new Typecho_Widget_Helper_Form_Element_Text('website', NULL, 'xxx.com', _t('Universal Analytics注册的域名'), _t('此域名是在GA注册的顶级域名或者二级域名，如xxx.com。'));
        $form->addInput($website);
		$otherid = new Typecho_Widget_Helper_Form_Element_Text('otherid', NULL, 'xxxxx', _t('其它统计代码'), _t('其它统计代码'));
        $form->addInput($otherid);
    }
    
    /**
     * 个人用户的配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}
    
    /**
     * 插件实现方法
     * 
     * @access public
     * @return void
     */
    public static function render()
    {
        $account = Typecho_Widget::widget('Widget_Options')->plugin('UniversalAnalytics')->account;
		$website = Typecho_Widget::widget('Widget_Options')->plugin('UniversalAnalytics')->website;
		$otherid = Typecho_Widget::widget('Widget_Options')->plugin('UniversalAnalytics')->otherid;
        echo "
<div style='display:none'>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
  ga('create', '{$account}', '{$website}');
  ga('send', 'pageview')</script>
{$otherid}</div> ";
    }
}