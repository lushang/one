<?php 
/**
 * sit_Locale 语言包类
 *
 * 系统语言包采用的是php-gettext模块.
 * 如果模板使用的是smarty.使用了smarty-gettext插件.插件地址http://sourceforge.net/projects/smarty-gettext/
 *  php-gettext的安装和使用(ubuntu平台下)
 *  1 Installation of gettext package: sudo apt-get install php-gettext
 *  2 Install locales: see all locales in the file vim /usr/share/i18n/SUPPORTED
 *  3 设置文件目录结构;如: Locale/zh_CN/LC_MESSAGES 或者 Locale/en_US/LC_MESSAGES
 *  4 如果是smarty模板(使用{t}你好{/t}标记)。生成.c格式的文件;如:php -q tsmarty2c.php  $file > text.c
 *  5 生成.po格式的文件;xgettext -o sit.po --join-existing --omit-header --no-location text.c 
 *  6 生成.mo格式的文件;msgfmt sit.po -o sit.mo
 *  7 移动mo文件到相应的Locale/en_US/LC_MESSAGES文件夹下面
 *
 */
class sit_Locale {
    /**
     * _options 设置语言包的选项 
     *
     * $this->_options['lang'] 应用程序使用什么语言包.php-gettext支持的所有语言都可以.
     * 在ubuntu下使用sudo vim /usr/share/i18n/SUPPORTED 主要是utf8编码
     * $this->_options['domain'] 生成的.mo文件的名字.一般是应用程序名
     *
     * @var array
     * @access protected
     */
    protected $_options; 
    /**
     * __construct 构造函数 对象初始化时设置语言包的参数 
     * 
     * @access public
     * @return void
     */
    public function __construct($lang=null) {
        //domain 域名 sit: 可以任意取个有意义的名字，不过要跟相应的.mo文件的文件名相同（不包括扩展名）。
        switch ( $lang ) {
            case 'cn':
            case 'zh_CN':
                $this->_options = array('lang' => 'zh_CN.utf8','domain'=>'sit');
                break;
            case 'zh_TW':
                $this->_options = array('lang' => 'zh_TW.utf8','domain'=>'sit');
                break;
            case 'eu':
            case 'en_US':
            case 'us':
                $this->_options = array('lang' => 'en_US.utf8','domain'=>'sit');
                break;
            case 'de':
                $this->_options = array('lang' => 'de_DE.utf8','domain'=>'sit');
                break;
            case 'fr':
                $this->_options = array('lang' => 'fr_FR.utf8','domain'=>'sit');
                break;
            default:
                $this->_options = array('lang' => 'en_US.utf8','domain'=>'sit');
                break;
        }
        $this->setApplicationLocale();
    }
    /**
     * setOptions 设置应用程序语言包的参数 放在在数组$this->_options中 
     * 
     * @param mixed $options 
     * @access public
     * @return void
     */
    public function setOptions($options) {
        if(!empty($options)) {
            foreach ($options as $key => $option) {
                $this->_options[$key] = $option;
            }
        }
    }
    /**
     * setApplicationLocale  设置应用程序语言包 
     * 
     * @access public
     * @return void
     */
    public function setApplicationLocale() {
        putenv('LANG='.$this->_options['lang']);
        setlocale(LC_ALL,$this->_options['lang']);
        bindtextdomain($this->_options['domain'],dirname(__FILE__).'/locale/');  //设置某个域的mo文件路径    
        textdomain($this->_options['domain']);  //设置gettext()函数从哪个域去找mo文件 
        bind_textdomain_codeset($this->_options['domain'],'UTF-8'); //设置mo文件的编码为UTF-8    
    }
}