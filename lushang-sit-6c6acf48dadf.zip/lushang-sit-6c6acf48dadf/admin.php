<?php

/* 
 * Design by lushang, copy right lushang 2013-2014
 * admin for the user to edit profile, delete classes / students, change pwd etc.
 * security!!!
 */

include_once 'header.php';
global $DatabaseServer,$DatabaseUsername,$DatabasePassword,$DatabaseName;

$userId = $_SESSION['sess_user_id'];
$userName = $_SESSION['sess_username'];
?>
<script src="dist/js/validator.min.js"></script>
<script type="text/javascript">
    //TODO change the alert to beautiful form!!
$(document).ready(function(){
    // validation
    $('#changePWDButton').on('click',function(){
        if($('#changePWDButton.disabled').length === 0) { //class disabled means data is no right.
            $.ajax({
                type: "POST",
                url: "dbprocess.php",
                data: $('#changePWD').serialize(),
                success: function(msg) {
                    alert(msg);  //TODO need to change to a beautiful UI
                }
            });
        }
    });
});
</script>
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
            <ul class="nav nav-sidebar">
                <li>
                    <a href="admin.php?changepwd" class="text-center">Change password</a>
                </li>
            </ul>
        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
            <?php if(isset($_GET['changepwd'])) { ?>
            <h1 class="page-header">Change the password for <?php echo $userName; ?></h1>
            <form class="form-horizontal" role="form" id="changePWD" method="post" data-toggle="validator">
                <input type="hidden" name="form" value="change_pwd">
                <div class="form-group">
                    <label class="col-sm-3 control-label"><?php echo _('CURRENT PASSWORD:') ?></label>
                    <div class="col-sm-9">
                        <input type="password" class="form-control" name="c_pwd" required>
                        <div class="help-block with-errors"></div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label"><?php echo _('NEW PASSWORD:') ?></label>
                    <div class="col-sm-9">
                        <input type="password" data-minlength="6" class="form-control" name="n_pwd" id="n_pwd" required>
                        <span class="help-block"><?php echo _("Minimum of 6 characters"); ?></span>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label"><?php echo _('NEW PASSWORD (AGAIN):') ?></label>
                    <div class="col-sm-9">
                        <input type="password" class="form-control" name="na_pwd" 
                               id="na_pwd" data-match="#n_pwd" data-match-error="Whoops, these don't match" required>
                        <div class="help-block with-errors"></div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-6 col-sm-offset-6">
                        <button type="submit" id="changePWDButton"  class="btn btn-primary" > <?php echo _('Change') ?> </button>
                    </div>
                </div>
            </form>
        </div>



<?php
            }
include 'footer.php';