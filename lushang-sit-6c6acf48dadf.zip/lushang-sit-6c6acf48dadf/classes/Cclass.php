<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of cClass
 *
 * @author PtM101
 */

class cClass {
    //put your code here
    private $class_id, $class_name, $grade_id, $school_id, $fellow_id, $attendance;
    //private $DatabaseServer,$DatabaseUsername,$DatabasePassword,$DatabaseName;
    private $my_sqli;
    
    function __construct($DatabaseServer,$DatabaseUsername,$DatabasePassword,$DatabaseName) {
        $this->class_id=NUll;
        $this->class_name=NULL;
        $this->grade_id = NULL;
        $this->fellow_id=NULL;
        $this->attendance=NULL;
        $this->school_id=NULL;
        //$this->DatabaseName = $DatabaseName; $this->DatabasePassword = $DatabasePassword;
        //$this->DatabaseServer = $DatabaseServer; $this->DatabaseUsername = $DatabaseUsername;
        $this->my_sqli = new mysqli($DatabaseServer,$DatabaseUsername,$DatabasePassword,$DatabaseName);
        $this->my_sqli->set_charset("utf8");
    }
    
    function __destruct() {
        if (isset($this->my_sqli)) {
            $this->my_sqli->close();
        }
    }
    
    function getInfo(){
        return array("class_id"=>$this->class_id, "class_name"=>$this->class_name, "school_id"=>  $this->school_id, "fellow_id"=>  $this->fellow_id, "attendance"=>  $this->attendance);
    }
    
    function setData(){
        $query="INSERT INTO `classes`(`class_id`, `class_name`, `school_id`, `fellow_id`, `attendance`) VALUES ($this->class_id,'$this->class_name',$this->school_id,$this->fellow_id,'$this->attendance')";
        $this->my_sqli->query($query);
        $result = $this->my_sqli->insert_id; // Returns the auto generated id used in the last query
        return $result;                      // If returns 0, means it's not success.
    }
    
    function setInfo($class_name, $school_id, $fellow_id, $attendance, $class_id='""'){
        if(!$this->class_id){
            $this->class_id=$class_id;
        }
        $this->class_name=$class_name;
        $this->school_id=$school_id;
        $this->fellow_id=$fellow_id;
        $this->attendance=$attendance;
    }
    
    function getClassId() {
        
    }
    
    function getClassName($class_id) {
        $query = "SELECT  `class_name` FROM `classes` WHERE `class_id` IN (".implode(',',$class_id).")";
        $result = $this->my_sqli->query($query,MYSQLI_STORE_RESULT);
        $res_arr = array();
        while($row = $result->fetch_assoc()) {
            $res_arr = array_merge($res_arr,array($row["class_name"]));
        }
        //$res_arr = $result->fetch_assoc();
        return $res_arr;
    }
    
}
