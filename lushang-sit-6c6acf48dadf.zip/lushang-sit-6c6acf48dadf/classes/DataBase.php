<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of dataBase
 *
 * @author PtM101
 */
class DataBase {
    //put your code here
    private $DatabaseServer,$DatabaseUsername,$DatabasePassword,$DatabaseName,$DatabasePort;
    private $connectstring,$connection;
            
    function __construct($DatabaseServer,$DatabaseUsername,$DatabasePassword,$DatabaseName,$DatabasePort) {
        $this->DatabaseServer=$DatabaseServer;
        $this->DatabaseName=$DatabaseUsername;
        $this->DatabasePassword=$DatabasePassword;
        $this->DatabaseName=$DatabaseName;
        $this->DatabasePort=$DatabasePort;
        $this->connection=NULL;
        $connectstring = '';
	if ($DatabaseServer != 'localhost') {
            $connectstring = "$DatabaseServer,";
        }
        /*if ($DatabasePort != '5432') {
            $connectstring .= "port=$DatabasePort ";
        }*/
        $connectstring .= "$DatabaseUsername,";
	if (!empty($DatabasePassword)) {
            $connectstring.="$DatabasePassword,";
        }
        $this->connectstring=$connectstring;
    }
    
    function __destruct() {
        mysql_close($this->connection);
    } 
    
    function db_show_error($sql,$failnote,$additional='') {
        global $SITNotifyAddress;
        echo '<BR />';
	PopTable('header',_('We have a problem, please contact technical support ...'));
    // TRANSLATION: do NOT translate these since error messages need to stay in English for technical support
	echo '<TABLE style="border-collapse:separate; border-spacing:10px;">
		<TR>
			<TD style="text-align:right"><b>Date:</b></TD>
			<TD><pre>'.date("m/d/Y h:i:s").'</pre></TD>
		</TR><TR>
			<TD style="text-align:right"><b>Failure Notice:</b></TD>
			<TD><pre> '.$failnote.' </pre></TD>
		</TR><TR>
			<TD style="text-align:right"><b>Additional Information:</b></TD>
			<TD>'.$additional.'</TD>
		</TR>
		</TABLE>';
	//Something you have asked the system to do has thrown a database error.  A system administrator has been notified, and the problem will be fixed as soon as possible.  It might be that changing the input parameters sent to this program will cause it to run properly.  Thanks for your patience.
	PopTable('footer');
	echo "<!-- SQL STATEMENT: \n\n $sql \n\n -->";
	if($SITNotifyAddress)
	{
		$message = "System: ".ParseMLField(Config('TITLE'))." \n";
		$message .= "Date: ".date("m/d/Y h:i:s")."\n";
		$message .= "Page: ".filter_input(INPUT_SERVER,'PHP_SELF').' '.ProgramTitle()." \n\n";
		$message .= "Failure Notice:  $failnote \n";
		$message .= "Additional Info: $additional \n";
		$message .= "\n $sql \n";
		$message .= "Request Array: \n".print_r($_REQUEST, true);
		$message .= "\n\nSession Array: \n".print_r($_SESSION, true);
		
		//modif Francois: add email headers
		$headers = 'From:'.$SITNotifyAddress."\r\n";
		$headers .= 'Return-Path:'.$SITNotifyAddress."\r\n"; 
		$headers .= 'Reply-To:'.$SITNotifyAddress . "\r\n" . 'X-Mailer: PHP/' . phpversion();
		$params = '-f '.$SITNotifyAddress;
		
		mail($SITNotifyAddress,'SIT Database Error',utf8_decode($message),$headers, $params);
	}
	die();
    }
            
    function DBQuery($sqlstring) {
        
        $this->connection = mysql_connect($this->connectstring);
	// Error code for both.
	if($this->connection === false)
	{
        // TRANSLATION: do NOT translate these since error messages need to stay in English for technical support
    	db_show_error("",sprintf('Could not Connect to Database Server \'%s\'',$this->DatabaseServer),mysql_error());
	}
	// TRANSLATION: do NOT translate these since error messages need to stay in English for technical support
	$sql = preg_replace("/([,\(=])[\r\n\t ]*''[\r\n\t]*(?!')/",'\\1NULL',$sqlstring);
	$result = mysql_query($sql,$this->connection);
	if($result===false)
	{
		$errstring = mysql_error();
		db_show_error($sql,"DB Execute Failed.",$errstring);
	}
	
	return $result;
    }
    
    
    
    
}
