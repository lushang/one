<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Fellow
 *
 * @author PtM101
 */
class Fellow {
    //unfinished class!!
    private $fellow_id,$class_id;
    
    function __construct($DatabaseServer,$DatabaseUsername,$DatabasePassword,$DatabaseName) {
        $this->fellow_id=NULL;
        $this->class_id=NULL;
        $this->DatabaseName = $DatabaseName; 
        $this->DatabasePassword = $DatabasePassword;
        $this->DatabaseServer = $DatabaseServer; 
        $this->DatabaseUsername = $DatabaseUsername;
    }
    
    function __destruct() {
        if (isset($this->my_sqli)) {
            $this->my_sqli->close();
        }
    }
    
    function setInfo($fellow_id){
        $this->fellow_id = $fellow_id;
    }
    
    function updateClassInfo($class_id){
        $this->my_sqli = new mysqli($this->DatabaseServer,$this->DatabaseUsername,$this->DatabasePassword,$this->DatabaseName);
        $this->my_sqli->set_charset("utf8");
        $query = "SELECT `class_id` FROM `fellows` WHERE `fellow_id`=$this->fellow_id";
        $result = $this->my_sqli->query($query,MYSQLI_STORE_RESULT);
        $res_arr = $result->fetch_assoc();
        if($res_arr["class_id"]){
           $class_id = $res_arr["class_id"].','.$class_id; 
        }
        $query_add="UPDATE `fellows` SET `class_id`='$class_id' WHERE `fellow_id`=$this->fellow_id";
        $this->my_sqli->query($query_add);
        return $class_id;
    }
    
    
}
