<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Student
 *
 * @author PtM101
 */

global $DatabaseServer,$DatabaseUsername,$DatabasePassword,$DatabaseName;

class Student {
    //class to Student
    private $student_id,$class_id,$school_id,$fellow_id,$name,$gender,$nationality,$birthday,$phone; 
    private $status,$note,$address;
    //private $DatabaseServer,$DatabaseUsername,$DatabasePassword,$DatabaseName;
    private $my_sqli;
            
    function __construct($DatabaseServer,$DatabaseUsername,$DatabasePassword,$DatabaseName,$student_id = NULL) {
        $this->student_id=$student_id;      $this->phone=NULL;
        $this->name=NULL;                   $this->class_id=NUll;
        $this->fellow_id=NULL;              $this->school_id=NULL; 
        $this->gender=NULL;                 $this->status=NULL;
        $this->nationality=NULL;            $this->note=NULL;
        $this->birthday=NULL;               $this->address=NULL;      
        //$this->DatabaseName = $DatabaseName; $this->DatabasePassword = $DatabasePassword;
        //$this->DatabaseServer = $DatabaseServer; $this->DatabaseUsername = $DatabaseUsername;
        $this->my_sqli = new mysqli($DatabaseServer,$DatabaseUsername,$DatabasePassword,$DatabaseName);
        $this->my_sqli->set_charset("utf8");
    }
    
    function __destruct() {
        if (isset($this->my_sqli)) {
            $this->my_sqli->close();
        }
    }
    
    function getData() {
        if($this->student_id != NULL) {
            $query = "SELECT  `class_id`, `school_id`, `fellow_id`, `name`, `gender`, `nationality`, `birthday`, `phone`, `status`, `note`, `address` FROM `students` WHERE `student_id`=".$this->student_id;
            $result = $this->my_sqli->query($query);
            $row = $result->fetch_assoc();
            $this->setInfo($row['class_id'], $row['school_id'], $row['fellow_id'], $row['name'], $row['gender'], $row['nationality'], $row['birthday'], $row['phone'], $row['address'], $row['note']);
            return 1;
        } else {
            return 0;
        }
    }
            
    function getInfo() {
        // get the student's all infomation, return an array of student's infomation
        return array("student_id"=>$this->student_id,"name"=>$this->name,"gender"=>$this->gender,"nationality"=>$this->nationality,"birthday"=>$this->birthday,"phone"=>$this->phone,"status"=>$this->status,"note"=>$this->note,"class_id"=>$this->class_id,"school_id"=>$this->school_id,"address"=>$this->address);
    }
    
    function setData() {
        //set the students's all infomation to the MySQL
        $query = "INSERT INTO `students`(`student_id`, `class_id`, `school_id`, `fellow_id`, `name`, `gender`, `nationality`, `birthday`, `phone`, `status`, `note`, `address`) VALUES ($this->student_id,$this->class_id,$this->school_id,$this->fellow_id,'$this->name','$this->gender','$this->nationality','$this->birthday','$this->phone','$this->status','$this->note','$this->address')";
        $this->my_sqli->query($query);
        $result = $this->my_sqli->insert_id; // Returns the auto generated id used in the last query
        return $result;
    }
    
    function setInfo($class_id,$school_id,$fellow_id,$name,$gender,$nationality,$birthday,$phone,$address,$note,$student_id ='""' ) {
        if(!$this->student_id) {
            $this->student_id = $student_id;
        }
        $this->class_id = $class_id;
        $this->school_id = $school_id;
        $this->fellow_id = $fellow_id;
        $this->name = $name;
        $this->gender = $gender;
        $this->nationality = $nationality;
        $this->birthday = $birthday;
        $this->phone = $phone;
        $this->address = $address;
        $this->note =$note;
    }
    
    function updateNote($note) {
        if($this->student_id) {
            $query = "SELECT `note` FROM `students` WHERE `student_id`=$this->student_id";
            $result = $this->my_sqli->query($query);
            $row = $result->fetch_assoc();
            $oldnote = $row['note'];
            $newnote = $oldnote."##note8888##".$note;
            $query2 = "UPDATE `students` SET `note`='$newnote' WHERE `student_id`=$this->student_id";
            $result2 = $this->my_sqli->query($query2);
            return $result2;
        } else {
            return 0;
        }
    }
    
}
