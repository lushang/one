<?php

/* 
 * database configure file .
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
    $DatabaseServer="127.0.0.1";
    $DatabaseUsername="root";
    $DatabasePassword="1qaz2wsx";
    $DatabaseName="sitcat";

function filter($original_data) {
    $data = trim(htmlentities(strip_tags($original_data)));
	
    if (get_magic_quotes_gpc()) {
        $data = stripslashes($data);
    }
    $data = mysql_real_escape_string($data);
	
    return $data;
}

// Password and salt generation
function PwdHash($pwd, $salt = null)
{
    if ($salt === null)     {
        $salt = substr(md5(uniqid(rand(), true)), 0, SALT_LENGTH);
    }
    else     {
        $salt = substr($salt, 0, SALT_LENGTH);
    }
    return $salt . sha1($pwd . $salt);
}