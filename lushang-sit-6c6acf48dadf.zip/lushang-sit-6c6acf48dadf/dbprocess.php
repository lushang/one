<?php

/* 
 * Design by lushang, copy right lushang 2013-2014
 * This file is to process the data from the user by update to the DB
 */
session_start();
$classes = scandir('classes/');
    foreach ($classes as $function) {
		//filter PHP files
        if (mb_strrchr($function, '.') == '.php') {
            require_once('classes/' . $function);
        }
    }
include_once 'dbc.php';
global $DatabaseServer,$DatabaseUsername,$DatabasePassword,$DatabaseName;
$formtype = filter_input(INPUT_POST, "form");

// add a class to the DB
if($formtype == "new_class") { 
    $class_name = filter_input(INPUT_POST, "class_name");
    $attendance = filter_input(INPUT_POST, "attendance");
    $fellow_id = $_SESSION['sess_user_id'];
    $school_id = $_SESSION['sess_school_id'];
    $cls = new cClass($DatabaseServer, $DatabaseUsername, $DatabasePassword, $DatabaseName);
    $cls->setInfo($class_name, $school_id, $fellow_id, $attendance);
    $class_id = $cls->setData();
    if($class_id != 0) {
    //sucess add a new class, update fellow's class info
        $fellow = new Fellow($DatabaseServer, $DatabaseUsername, $DatabasePassword, $DatabaseName);
        $fellow->setInfo($fellow_id);
        $class_id_new = $fellow->updateClassInfo($class_id);
        unset($class_name);
        unset($attendance);
        $_SESSION['sess_class_id'] = explode(',', $class_id_new);
        echo "The class information has been saved!";
    } else {
        echo "fail to save the student information!";
    }
}

// add a student to the DB
if($formtype == 'new_student') {
    $student_name = filter_input(INPUT_POST, "student_name");
    $class_id = filter_input(INPUT_POST, "class_id");
    $gender = filter_input(INPUT_POST, "gender");
    $nationality = filter_input(INPUT_POST, "nationality");
    $birthday = filter_input(INPUT_POST, "birthday");
    $phone = filter_input(INPUT_POST, "phone");
    $address = filter_input(INPUT_POST, "address");
    $note_date = filter_input(INPUT_POST, 'note_date');
    $note = filter_input(INPUT_POST, "note");
    $notem= $note_date.'##time8888##'.$note;
    $fellow_id = $_SESSION['sess_user_id'];
    $school_id = $_SESSION['sess_school_id'];
    $student = new Student($DatabaseServer, $DatabaseUsername, $DatabasePassword, $DatabaseName);
    $student->setInfo($class_id, $school_id, $fellow_id, $student_name, $gender, $nationality, $birthday, $phone, $address, $notem);
    $sid = $student->setData(); //get student id if success inserting
    if($sid != 0) {
        //update the tracker
        $query = "SELECT `tracker_id`  FROM `tracker` WHERE `class_id`=$class_id";
        $my_sqli = new mysqli($DatabaseServer,$DatabaseUsername,$DatabasePassword,$DatabaseName);
        $my_sqli->set_charset("utf8");
        $result = $my_sqli->query($query);
        if($result->num_rows > 0) { // the class has tracker info already
            while($row = $result->fetch_assoc()) {
                $query_t = "INSERT INTO `student_tracker`(`tid`,`tracker_id`, `score`, `student_id`) VALUES ('',".$row['tracker_id'].",NULL,$sid)";
                $my_sqli->query($query_t);
            }
            $my_sqli->close();
        }
        echo "The student information has been saved!";
    } else {
        echo "fail to save the student information!";
    }       
}

// update tracker
if($formtype == "update_tracker") {
    $student_ids_raw = explode("_", filter_input(INPUT_POST, "student_ids"));
    $student_ids = array_slice($student_ids_raw,1);
    $class_id = filter_input(INPUT_POST, "class_id");
    $tracker_type = filter_input(INPUT_POST, "tracker_type");
    $tracker_date = filter_input(INPUT_POST, "tracker_date");
    $full_mark = filter_input(INPUT_POST, "full_mark");
    $my_sqli = new mysqli($DatabaseServer,$DatabaseUsername,$DatabasePassword,$DatabaseName);
    $my_sqli->set_charset("utf8");
    $insertFlag = $my_sqli->query("INSERT INTO `tracker`(`tracker_id`, `class_id`, `tracker_date`, `tracker_type`, `full_mark`, `average`, `max`, `min`, `passrate`, `excellent_rate`) VALUES ('',$class_id,'$tracker_date','$tracker_type',$full_mark,'NULL','NULL','NULL','NULL','NULL')");
    if($insertFlag == TRUE) {
        $tracker_id = $my_sqli->insert_id; // Returns the auto generated id used in the last query
        $score_sum =0;
        $index = 0;
        $score60 = 0;
        $score80 = 0;
        $scoremax =0;
        $scoremin = $full_mark;
        foreach ($student_ids as $s_id) {
            $score = filter_input(INPUT_POST, "score_".$s_id);
            if($score<0 || $score >$full_mark) { // TODO:make invalid data NULL
                $score = NULL;
            }
            $query = "INSERT INTO `student_tracker`(`tid`,`tracker_id`, `score`, `student_id`) VALUES ('',$tracker_id,'$score',$s_id)";
            $my_sqli->query($query);
            if($score != NULL) {
                $score_sum +=$score;
                $index++;
                if($score>=$full_mark*0.6) {
                    $score60 ++;
                }
                if($score>=$full_mark*0.8) {
                    $score80++;
                }
                if($score>$scoremax) {
                    $scoremax = $score;
                }
                if($score<$scoremin) {
                    $scoremin = $score;
                }
            }
        
        }
        if($index != 0) {
            $score_average = $score_sum/$index;
            $score60 /= $index;
            $score80 /= $index;
        } else {
            $score_average = 0;
            $score60 = 0;
            $score80 = 0;
        }
        $query = "UPDATE `tracker` SET `average`=$score_average,`max`=$scoremax,`min`=$scoremin,`passrate`=$score60,`excellent_rate`=$score80 WHERE `tracker_id`=$tracker_id";
        $my_sqli->query($query);
        $my_sqli->close();
        echo "the tracker has been updated!";
    } else {
        echo "fail to update the tracker!";
    }
}

// add a note
if($formtype == "add_note") {
    $student_id = filter_input(INPUT_POST, 'student_id');
    $date = filter_input(INPUT_POST, 'date');
    $note = filter_input(INPUT_POST, 'note');
    $notem=$date."##time8888##".$note;
    $student = new Student($DatabaseServer,$DatabaseUsername,$DatabasePassword,$DatabaseName,$student_id);
    $result = $student->updateNote($notem);
    if($result == true ) {
        header('Content-type: text/xml');
        echo "<notemeta>";
        echo '<date>'.$date."</date>";
        echo "<note>".$note."</note>";
        echo "</notemeta>";
    }else{
        echo 'false';
    }
}

//change passsword
if($formtype == "change_pwd") {
    $userName = $_SESSION['sess_username'];
    $cPass = filter_input(INPUT_POST, 'c_pwd'); // current password
    $nPass =  strip_tags(substr(filter_input(INPUT_POST, 'n_pwd'),0,32)); // new password
    $query = "SELECT `pwd` FROM `fellows` WHERE `username`='$userName'";
    $my_sqli = new mysqli($DatabaseServer,$DatabaseUsername,$DatabasePassword,$DatabaseName);
    $reult = $my_sqli->query($query);
    $row = $reult->fetch_assoc();
    $oPass = $row['pwd']; // old password stored in DB crypt(md5($cPass),  md5($userName)) == $oPass
    $cyPass = crypt(md5($nPass),md5($userName));
    if(crypt(md5($cPass),  md5($userName)) == $oPass) { // match
        $queryInsert = "UPDATE `fellows` SET `pwd`='$cyPass' WHERE `username`='$userName'";
        if( $my_sqli->query($queryInsert)) {
            echo " Success: password has changed!";
        } else {
            echo "Failed: password doesn't change!";
        }
    } else { // not match
        echo "Failed: password doesn't match!";
    }
}