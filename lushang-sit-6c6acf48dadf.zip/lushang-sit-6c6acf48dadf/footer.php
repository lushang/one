<?php

/* 
 * Design by lushang, copy right lushang 2013-2014
 */

?>
<div class="footer">
    <div class="container">
        <p class="text-muted text-center">Copyright © 2013-2015 WT-lab All Rights Reserved</p>
    </div>  
</div>
</body>
</html>