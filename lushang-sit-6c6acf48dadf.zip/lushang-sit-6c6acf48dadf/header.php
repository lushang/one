<?php
//Start session
session_start();

include_once 'dbc.php';

$classes = scandir('classes/');
    foreach ($classes as $function) {
		//filter PHP files
        if (mb_strrchr($function, '.') == '.php') {
            require_once('classes/' . $function);
        }
    }
 
//Check whether the session variable SESS_MEMBER_ID is present or not
if(!isset($_SESSION['sess_user_id']) || (trim($_SESSION['sess_user_id']) == '')) {
    header("location: login.html");
    exit();
}
//check whether the user logout or not
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset='utf-8'/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    
    <!-- Bootstrap core CSS -->
    <link href="dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Custom styles -->
    <link href="dist/css/mainstyle.css" rel="stylesheet">
    <style type="text/css">
        body { padding-top: 50px; padding-bottom: 70px}
    </style>
    
    <script src="http://cdn.bootcss.com/jquery/2.1.1/jquery.min.js" type="text/javascript"></script>
    <link type="text/css" rel="stylesheet" href="http://cdn.bootcss.com/jqueryui/1.11.2/jquery-ui.css">
    <script type="text/javascript" src="http://cdn.bootcss.com/jqueryui/1.11.2/jquery-ui.min.js"></script>
    <script type="text/javascript" src="dist/js/bootstrap.min.js"></script>
    
    <title><?php echo $_SESSION["sess_username"] ?> to SIT</title>
</head>
 
<body>
    <!-- need to change the logo -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <div class="container">
          <div class="navbar-header">
              <img  src='ox.png' height="50" alt="main page"/>
          </div>
          <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li><a href="home.php">SIT</a></li>
            <li><a href="new.php">New</a></li>
            <li><a href="view.php">View</a></li>
            <li><a href="update.php">Update</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
              <li><a href="admin.php"><?php echo $_SESSION["sess_username"] ?></a></li>
            <li><a href="home.php?logout">Sign out</a></li>
          </ul>
        </div>
      </div>
    </nav>
