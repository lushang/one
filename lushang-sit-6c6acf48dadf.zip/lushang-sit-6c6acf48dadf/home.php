<?php
include_once 'header.php';
include_once 'dbc.php';
global $DatabaseServer,$DatabaseUsername,$DatabasePassword,$DatabaseName;

// first use the SIT system
if($_SESSION['sess_class_id'][0]==NULL) { 
    echo "<div class='container-fluid'>";
    echo "<div class='alert alert-danger' role='alert'>"
        ._("To use the SIT system, you should create a ")
            ." <a class='alert-link' href='new.php?new_class'>class</a> first</div>";
    echo "</div>";
}

// Sign out
if(filter_input(INPUT_GET, "logout")!==null){
    session_destroy();
    header("location: login.html");
    exit();
}

if(filter_input(INPUT_GET, "admin")!==null) {
    
}

include 'footer.php';