<?php
ob_start();
session_start();
require_once 'dbc.php';
$err = array();
$username = filter(filter_input(INPUT_POST, "username"));
$password = filter(filter_input(INPUT_POST, "password"));
 
$my_sqli = new mysqli($DatabaseServer,$DatabaseUsername,$DatabasePassword,$DatabaseName);
$my_sqli->set_charset("utf8"); 
$query = "SELECT * FROM `fellows` WHERE username = '$username';";
 
$result = $my_sqli->query($query);
 
if($result->num_rows == 0) { // User not found. So, redirect to login_form again.   
    $err[] = "Error - Invalid login. No such user exists";
    header('Location: login.html');
} else {  //the DB has this user
    $userData = $result->fetch_assoc();
    //$hash = hash('sha256', $userData['salt'] . hash('sha256', $password) );
     //print_r($userData);
    if(crypt(md5($password),md5($username)) != $userData['pwd']) // Incorrect password. So, redirect to login_form again.
    {
        header('Location: login.html');
    }else{ // Redirect to home page after successful login.
	session_regenerate_id();
	$_SESSION['sess_user_id'] = $userData['fellow_id'];
	$_SESSION['sess_username'] = $userData['username'];
        $_SESSION['sess_class_id'] = explode(',', $userData['class_id']);
        $_SESSION['sess_school_id'] = $userData['school_id'];
	session_write_close();
        header('Location: home.php');
    }
}
