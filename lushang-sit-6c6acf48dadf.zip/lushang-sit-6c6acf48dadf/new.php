<?php

/* 
 * Design by lushang, copy right lushang 2013-2014
 */
include_once 'header.php';
global $DatabaseServer,$DatabaseUsername,$DatabasePassword,$DatabaseName;
?>

<link rel="stylesheet" href="dist/css/validationEngine.jquery.css">
<script src="dist/js/jquery.validationEngine.js"></script>

<script type="text/javascript">
$(document).ready(function(){
    // validation
    $('newClass').validationEngine();
    
    $('#newClassButton').on('click',function(){
        var $btn = $(this).button('loading');
        $.ajax({
            type: "POST",
            url: "dbprocess.php",
            data: $("#newClass").serialize(),
            success: function(msg) {
                if(msg) {
                    alert("data saved!"+msg); 
                } else {
                    alert("Error: "+msg);
                }
                location.reload();
            }
        });
        $btn.button('reset');
    });
    $('#newStudentButton').on('click',function(){
        $.ajax({
            type: "POST",
            url: "dbprocess.php",
            data: $('#newStudent').serialize(),
            success: function(msg) {
                if(msg) {
                    alert("Data saved: "+msg);
                    location.reload();
                } else {
                    alert("Error: "+msg);
                }
            }
        });
    });
});
</script>
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
            <ul class="nav nav-sidebar">
                <li>
                    <a href="new.php?new_class">Add a class</a>
                    <a href="new.php?new_student">Add a student</a>
                </li>
            </ul>
        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
<?php
// new class form
if(isset($_GET['new_class'])) { ?>
            <h1 class='page-header'>Input class info</h1>
            <form class="form-horizontal" role="form" id="newClass" method="post">
                <input type="hidden" name="form" value="new_class">
                <div class="form-group">
                    <label class="col-sm-2 control-label"><?php echo _('Class name') ?></label>
                    <div class="col-sm-4">
                        <input type="text" class="form-control" name="class_name" placeholder="class name" required>
                    </div>
                    <label class="col-sm-2 control-label"><?php echo _("Attendance") ?></label>
                    <div class="col-sm-4">
                        <input type="number" class="form-control validate[required]" name="attendance" placeholder="attendance">
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-6 col-sm-offset-6">
                        <button id="newClassButton"  class="btn btn-default" > <?php echo _('Add') ?> </button>
                    </div>
                </div>
            </form>
    
<?php    
}

// new student form
if(isset($_GET["new_student"])){
    $class_id = $_SESSION['sess_class_id'];
    $cls = new cClass($DatabaseServer, $DatabaseUsername, $DatabasePassword, $DatabaseName);
    $class_name = $cls->getClassName($class_id);
    $class_m = array_combine($class_id, $class_name);
    $gender = array("boy","girl");
?>
            <h1 class='page-header'>Input student info</h1>
            <form class="form-horizontal" role="form" id="newStudent" method="post">
                <input type="hidden" name="form" value="new_student">
                <div class="form-group">
                    <label  class="col-sm-2 control-label"><?php echo _('Student name') ?></label>
                    <div class="col-sm-4">
                        <input type="text" class="form-control" name="student_name" placeholder="student name" required="required">
                    </div>
                    <label class="col-sm-2 control-label"><?php echo _("Class name") ?></label>
                    <div class="col-sm-4">
                        <select class="form-control" name="class_id" required>
                            <?php
                            foreach ($class_m as $cid => $cname) {
                                echo "<option value='$cid'>$cname</option>";
                            } ?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 control-label"><?php echo _("Gender") ?></label>
                    <div class="col-md-4">
                        <label class="radio-inline">
                            <input type="radio" name="gender"  value="boy" />
                            <?php echo _("boy"); ?> </label>

                        <label class="radio-inline">
                            <input type="radio" name="gender"  value="girl" />
                            <?php echo _("girl"); ?> </label>
                    </div>
                    <label class="col-sm-2 control-label"><?php echo _("Nationality") ?></label>
                    <div class="col-sm-4">
                        <input type="text" class="form-control" name="nationality" placeholder="nationality">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 control-label"><?php echo _("Birthday") ?></label>
                    <div class="col-sm-4">
                        <input type="date" class="form-control" name="birthday">
                    </div>
                    <label class="col-sm-2 control-label"><?php echo _("Phone") ?></label>
                    <div class="col-sm-4">
                        <input type="text" class="form-control" name="phone" placeholder="phone number">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 control-label"><?php echo _("Address") ?></label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="address" placeholder="address">
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-4 col-sm-offset-2">
                        <h4><?php echo _("Take a note"); ?></h4>
                    </div>
                    <label class="col-sm-2 control-label"><?php echo _("Note date") ?></label>
                    <div class="col-sm-4">
                        <input type="date" class="form-control" name="note_date" >
                    </div>
                </div>
                <div class="form-group">
                    
                </div>
                <div class="form-group">
                    <label class="col-sm-2 control-label"><?php echo _("Note") ?></label>
                    <div class="col-sm-10">
                        <textarea rows="3" class="form-control" name="note" placeholder="note here"></textarea>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-6 col-sm-offset-6">
                        <button id="newStudentButton" class="btn btn-default"><?php echo _('Add') ?></button>
                    </div>
                </div>
            </form>
<?php
}

echo "</div></div></div>";
include 'footer.php';