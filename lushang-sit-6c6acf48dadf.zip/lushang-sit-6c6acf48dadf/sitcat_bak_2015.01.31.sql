-- phpMyAdmin SQL Dump
-- version 4.0.9
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 31, 2015 at 11:24 AM
-- Server version: 5.6.14
-- PHP Version: 5.5.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sitcat`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE IF NOT EXISTS `address` (
  `address_id` int(11) NOT NULL AUTO_INCREMENT,
  `sub_village` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `village` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `town` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `county` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `province` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='students address' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE IF NOT EXISTS `classes` (
  `class_id` int(11) NOT NULL AUTO_INCREMENT,
  `class_name` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `school_id` int(11) DEFAULT NULL,
  `fellow_id` int(11) DEFAULT NULL,
  `attendance` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`class_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=71 ;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`class_id`, `class_name`, `school_id`, `fellow_id`, `attendance`) VALUES
(36, '133班', 12, 23, 47),
(39, '138班', 1, 11, 52),
(40, '139班', 1, 11, 48),
(41, '142班', 1, 11, 45),
(70, '134班', 1, 11, 52);

-- --------------------------------------------------------

--
-- Table structure for table `fellows`
--

CREATE TABLE IF NOT EXISTS `fellows` (
  `fellow_id` int(11) NOT NULL AUTO_INCREMENT,
  `school_id` int(11) NOT NULL,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `gender` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `birthday` date NOT NULL,
  `class_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `co_fellow_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `pwd` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `private_level` int(11) NOT NULL,
  PRIMARY KEY (`fellow_id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `fellows`
--

INSERT INTO `fellows` (`fellow_id`, `school_id`, `name`, `gender`, `phone`, `email`, `birthday`, `class_id`, `co_fellow_id`, `username`, `pwd`, `private_level`) VALUES
(1, 1, 'luo', 'male', '13888888888', 'luo@tao.com', '2000-01-01', '1', '11,111,1111', '1', '123456', 1),
(11, 1, 'root', 'male', '13888888888', 'lud', '2000-01-01', '39,40,41,70', '1,111', 'root', '1qaz2wsx', 1);

-- --------------------------------------------------------

--
-- Table structure for table `grades`
--

CREATE TABLE IF NOT EXISTS `grades` (
  `grade_id` int(11) NOT NULL,
  `grade` set('1','2','3','4','5','6','7','8') COLLATE utf8_unicode_ci NOT NULL,
  `school_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `schools`
--

CREATE TABLE IF NOT EXISTS `schools` (
  `school_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `short_name` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `county` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `principal` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`school_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `schools`
--

INSERT INTO `schools` (`school_id`, `title`, `short_name`, `address`, `county`, `city`, `principal`) VALUES
(1, '昌宁县更戛中学', '更戛中学', '更戛乡更戛中学', '昌宁', '保山', '刘冰');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE IF NOT EXISTS `students` (
  `student_id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `fellow_id` int(11) NOT NULL,
  `name` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` set('boy','girl','secret') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'secret',
  `nationality` varchar(6) COLLATE utf8_unicode_ci DEFAULT '汉族',
  `birthday` date DEFAULT '2000-01-01',
  `phone` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` set('0','1','2','3') COLLATE utf8_unicode_ci DEFAULT NULL,
  `note` text COLLATE utf8_unicode_ci,
  `address` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`student_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=30 ;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`student_id`, `class_id`, `school_id`, `fellow_id`, `name`, `gender`, `nationality`, `birthday`, `phone`, `status`, `note`, `address`) VALUES
(2, 1, 12, 1, 'pan pan', '', 'some', '2000-01-01', '13888888288', '', '2014-11-17##time8888##somethinghappend', '更戛中学'),
(3, 35, 1, 11, '孟香秀', '', '', '0000-00-00', '13888888888', '', '2014-11-17##time8888##somethinghappend', '西河村'),
(5, 40, 1, 11, '罗艳军', '', '汉族', '2000-06-13', '13555555555', '', '2014-11-17##time8888##somethinghappend', '弥合'),
(6, 40, 1, 11, '王杰', '', '汉族', '2001-02-04', '15155555555', '', '2014-11-17##time8888##somethinghappend', '懒巴赫'),
(7, 40, 1, 11, '鲁智平', '', '汉族', '2001-12-04', '18666666666', '', '2014-11-17##time8888##somethinghappend', '更戛'),
(8, 40, 1, 11, '李春平', 'boy', '', '0000-00-00', '', '', '2014-11-17##time8888##somethinghappend', ''),
(9, 40, 1, 11, '字菲凯', 'boy', '', '0000-00-00', '', '', '2014-11-17##time8888##somethinghappend', ''),
(10, 39, 1, 11, '赵民锋', 'boy', '汉族', '2000-10-01', '', '0', '2014-11-17##time8888##somethinghappend##note8888##2014-11-16##time8888##something##note8888##2014-11-16##time8888##somethingagain##note8888##2014-11-17##time8888##agian and again##note8888##2014-11-17##time8888##末末额的##note8888##2014-11-17##time8888##什么情况##note8888##2014-11-17##time8888##真是什么情况##note8888##2014-11-17##time8888##这次又是什么情况##note8888##2014-11-17##time8888##希望这次是个好情况##note8888##2014-11-17##time8888##现在终于搞定这个功能了##note8888##2014-11-17##time8888##现在才叫终于好了##note8888##2014-11-17##time8888##嘿嘿  说什么好呢##note8888##2014-11-17##time8888##现在更加合适##note8888##2014-12-23##time8888##something happed!##note8888##2015-01-10##time8888##now it shoud works##note8888##2015-01-10##time8888##if it works, then just css##note8888##2015-01-10##time8888##sgd##note8888##2015-01-10##time8888##somte dsga ##note8888##2015-01-10##time8888##try to be##note8888##2015-01-10##time8888##some thing that should be simple##note8888##2015-01-10##time8888##something should success##note8888##2015-01-10##time8888##waring ??##note8888##2015-01-10##time8888##为什么不可以呢？？##note8888##2015-01-10##time8888##这次应该可以隐藏Add##note8888##2015-01-10##time8888##这次隐藏的更漂亮##note8888##2015-01-10##time8888##这次能不能成功隐藏##note8888##2015-01-10##time8888##能不能成功呢##note8888##2015-01-10##time8888##不知道能不能成功##note8888##2015-01-10##time8888##这个更好完？##note8888##2015-01-10##time8888####note8888##2015-01-10##time8888##成功不成功？##note8888##2015-01-10##time8888##塞满的感觉是如何的？##note8888##2015-01-10##time8888##需要继续塞满？\r\n##note8888##2015-01-10##time8888##么##note8888##2015-01-11##time8888##hh##note8888##2015-01-11##time8888##mi', '更戛乡大沙坝村大沙坝'),
(11, 39, 1, 11, '李建明', 'boy', '汉族', '2000-01-01', '', '0', '2014-11-17##time8888##somethinghappend', '更戛乡更戛村马鹿寨'),
(12, 39, 1, 11, '陈俊澎', 'boy', '汉族', '2001-02-03', '', '0', '2014-11-17##time8888##somethinghappend', '更戛乡大沙坝村大沙坝'),
(13, 39, 1, 11, '张志兵', 'boy', '汉族', '2000-10-11', '', '0', '2014-11-17##time8888##somethinghappend', '更戛乡西河村落水坑'),
(14, 39, 1, 11, '毕艳萍', 'girl', '汉族', '2000-04-05', '', '0', '2014-11-17##time8888##somethinghappend', '更戛乡米河村大平掌'),
(15, 39, 1, 11, '马银菊', 'girl', '汉族', '2000-11-15', '', '', '2014-11-17##time8888##somethinghappend', '更戛乡米河村新寨'),
(16, 39, 1, 11, '戈江', 'girl', '汉族', '2001-02-07', '', '', '2014-11-17##time8888##somethinghappend', '更戛乡木瓜树村洼子寨'),
(17, 39, 1, 11, '范国会', 'girl', '汉族', '2000-02-07', '', '', '2014-11-17##time8888##somethinghappend', '更戛乡西桂村芒平'),
(18, 41, 1, 11, '李成', 'boy', '汉族', '0000-00-00', '', '', '##time8888##', ''),
(19, 42, 1, 11, '何安', 'boy', '汉族', '2000-02-08', '13812341234', '', '2015-01-13##time8888##练体育！', '老街老街'),
(20, 42, 1, 11, '普东', 'boy', '', '0000-00-00', '', '', '##time8888##', ''),
(21, 66, 1, 11, '某人', '', '', '0000-00-00', '', '', '##time8888##', ''),
(22, 39, 1, 11, '某某', '', '', '0000-00-00', '', '', '##time8888##', ''),
(23, 41, 1, 11, '张智聪', 'boy', '汉族', '2000-06-13', '', '', '2015-01-14##time8888##初三降级而来', '西米'),
(24, 41, 1, 11, '夏从美', 'girl', '汉族', '0000-00-00', '', '', '##time8888##', ''),
(25, 41, 1, 11, '郭兰从', 'girl', '', '0000-00-00', '', '', '##time8888##', ''),
(26, 41, 1, 11, '某某', 'girl', '', '0000-00-00', '', '', '##time8888##', ''),
(27, 41, 1, 11, '尹家恒', '', '', '0000-00-00', '', '', '##time8888##', ''),
(28, 41, 1, 11, '李正梁', '', '', '0000-00-00', '', '', '##time8888##', ''),
(29, 41, 1, 11, '李智美', 'girl', '', '0000-00-00', '', '', '##time8888##', '');

-- --------------------------------------------------------

--
-- Table structure for table `student_tracker`
--

CREATE TABLE IF NOT EXISTS `student_tracker` (
  `tid` int(11) NOT NULL AUTO_INCREMENT,
  `tracker_id` int(11) NOT NULL,
  `score` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `student_id` int(11) NOT NULL,
  PRIMARY KEY (`tid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=192 ;

--
-- Dumping data for table `student_tracker`
--

INSERT INTO `student_tracker` (`tid`, `tracker_id`, `score`, `student_id`) VALUES
(43, 18, '52', 10),
(44, 18, '71', 11),
(45, 18, '47', 12),
(46, 18, '63', 13),
(47, 18, '38', 14),
(48, 18, '54', 15),
(49, 18, '30', 16),
(50, 18, '43', 17),
(67, 21, '4.5', 10),
(68, 21, '4.5', 11),
(69, 21, '4', 12),
(70, 21, '4.5', 13),
(71, 21, '4.5', 14),
(72, 21, '4.5', 15),
(73, 21, '3', 16),
(74, 21, '', 17),
(96, 25, '80', 10),
(97, 25, '', 11),
(98, 25, '', 12),
(99, 25, '77', 13),
(100, 25, '45', 14),
(101, 25, '72', 15),
(102, 25, '46', 16),
(103, 25, '50', 17),
(104, 26, '65', 10),
(105, 26, '56', 11),
(106, 26, '47', 12),
(107, 26, '56', 13),
(108, 26, '49', 14),
(109, 26, '67', 15),
(110, 26, '52', 16),
(111, 26, '40', 17),
(112, 27, '5', 10),
(113, 27, '4', 11),
(114, 27, '4', 12),
(115, 27, '4.5', 13),
(116, 27, '3.5', 14),
(117, 27, '4.5', 15),
(118, 27, '4', 16),
(119, 27, '4', 17),
(120, 28, '80', 10),
(121, 28, '80', 11),
(122, 28, '60', 12),
(123, 28, '70', 13),
(124, 28, '60', 14),
(125, 28, '70', 15),
(126, 28, '56', 16),
(127, 28, '56', 17),
(130, 29, '100', 18),
(131, 30, '90', 18),
(132, 31, '90', 18),
(133, 32, '80', 18),
(134, 33, '99', 18),
(135, 34, '98', 18),
(136, 35, '80', 10),
(137, 35, '80', 11),
(138, 35, '80', 12),
(139, 35, '80', 13),
(140, 35, '80', 14),
(141, 35, '80', 15),
(142, 35, '80', 16),
(143, 35, '80', 17),
(144, 35, '80', 22),
(145, 36, '70', 10),
(146, 36, '70', 11),
(147, 36, '70', 12),
(148, 36, '70', 13),
(149, 36, '70', 14),
(150, 36, '70', 15),
(151, 36, '70', 16),
(152, 36, '70', 17),
(153, 36, '70', 22),
(154, 37, '70', 18),
(155, 37, '70', 23),
(156, 37, '70', 24),
(157, 37, '70', 25),
(158, 30, NULL, 28),
(159, 29, NULL, 29),
(160, 30, NULL, 29),
(161, 31, NULL, 29),
(162, 32, NULL, 29),
(163, 33, NULL, 29),
(164, 34, NULL, 29),
(165, 37, NULL, 29),
(166, 38, '78', 18),
(167, 38, '78', 23),
(168, 38, '78', 24),
(169, 38, '78', 25),
(170, 38, '78', 26),
(171, 38, '78', 27),
(172, 38, '78', 28),
(173, 38, '78', 29),
(174, 39, '9', 10),
(175, 39, '9', 11),
(176, 39, '9', 12),
(177, 39, '9', 13),
(178, 39, '9', 14),
(179, 39, '9', 15),
(180, 39, '9', 16),
(181, 39, '9', 17),
(182, 39, '9', 22),
(183, 40, '8', 10),
(184, 40, '8', 11),
(185, 40, '8', 12),
(186, 40, '8', 13),
(187, 40, '8', 14),
(188, 40, '8', 15),
(189, 40, '8', 16),
(190, 40, '8', 17),
(191, 40, '8', 22);

-- --------------------------------------------------------

--
-- Table structure for table `tracker`
--

CREATE TABLE IF NOT EXISTS `tracker` (
  `tracker_id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `tracker_time` date DEFAULT NULL,
  `tracker_type` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `full_mark` smallint(4) DEFAULT NULL,
  `average` float DEFAULT NULL,
  `max` smallint(4) DEFAULT NULL,
  `min` smallint(4) DEFAULT NULL,
  `passrate` float DEFAULT NULL,
  `excellent_rate` float DEFAULT NULL,
  PRIMARY KEY (`tracker_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=41 ;

--
-- Dumping data for table `tracker`
--

INSERT INTO `tracker` (`tracker_id`, `class_id`, `tracker_time`, `tracker_type`, `full_mark`, `average`, `max`, `min`, `passrate`, `excellent_rate`) VALUES
(18, 39, '2014-09-28', '第二章', 100, 49.75, 71, 30, 0.25, 0),
(21, 39, '2014-10-20', '第三章作业', 5, 4.21429, 5, 3, 1, 0.857143),
(25, 39, '2014-10-22', '第三章考试', 100, 61.6667, 80, 45, 0.5, 0.166667),
(26, 39, '2014-10-31', '期中模拟1', 100, 54, 67, 40, 0.25, 0),
(27, 39, '2014-11-03', '作业检查', 5, 4.1875, 5, 4, 1, 0.875),
(28, 39, '2015-01-10', '单元检测4', 100, 66.5, 80, 56, 0.75, 0.25),
(29, 41, '2015-01-14', '期末', 100, 100, 100, 100, 1, 1),
(30, 41, '2015-01-15', '单元检测', 100, 90, 90, 90, 1, 1),
(31, 41, '2015-01-15', '单元检测', 100, 90, 90, 90, 1, 1),
(32, 41, '2014-12-30', '单元测验2', 100, 80, 80, 80, 1, 1),
(33, 41, '2015-01-14', '单元检测3', 100, 99, 99, 99, 1, 1),
(34, 41, '2015-01-14', '单元检测4', 100, 98, 98, 98, 1, 1),
(35, 39, '2015-01-14', '最新测试', 100, 80, 80, 80, 1, 1),
(36, 39, '2015-01-14', 'new test', 100, 70, 70, 70, 1, 0),
(37, 41, '2015-01-15', '一次测试', 100, 70, 70, 70, 1, 0),
(38, 41, '2015-01-15', '某次测验', 100, 78, 78, 78, 1, 0),
(39, 39, '2015-01-20', 'test 3', 10, 9, 9, 9, 1, 1),
(40, 39, '2015-01-20', 'test 4', 10, 8, 8, 8, 1, 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
