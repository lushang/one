<?php
    /**
$icon = "http://warmblogtest-emlog.stor.sinaapp.com/upload/thum52-4cbf1fbc308d29ea9273ed4cbb293f4820150311143452.jpg";
$name_offset = strpos($icon,'upload');
$icon_1 = substr($icon,$name_offset);
$icon_2 = str_replace('thum52-', '', $icon_1);
$icon_3 = preg_replace("/^(.*)\/(.*)$/", "\$1/thum-\$2", $icon_2);
print_r('icon:'.$icon_1.'<br/>');
print_r($icon_2);
print('<br/>');
print_r($icon_3);
print('<br/>');*/
   // echo ''.gmdate('Ym');

$a = [1,2,3];
$b = 4;
array_push($a,$b);
print_r($a);