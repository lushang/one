<?php
include_once 'dbc.php';
global $DatabaseServer,$DatabaseUsername,$DatabasePassword,$DatabaseName;
$classes = scandir('classes/');
    foreach ($classes as $function) {
		//filter PHP files
        if (mb_strrchr($function, '.') == '.php') {
            require_once('classes/' . $function);
        }
    }
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/* for the function trim
$text = "\t\tThese are a few words :) ...  ";

echo trim($text);           // "These are a few words :) ..."
echo trim($text, " \t.");   // "These are a few words :)"

// trim the ASCII control characters at the beginning and end of $binary
// (from 0 to 31 inclusive)
$clean = trim($binary, "\x00..\x1F");

// for the Class Cclass
    include_once 'data.php';
    require_once 'classes/Cclass.php';
    header("Content-Type:text/html;charset=UTF-8");
    global $DatabaseServer,$DatabaseUsername,$DatabasePassword,$DatabaseName;
    $a = new Cclass($DatabaseServer,$DatabaseUsername,$DatabasePassword,$DatabaseName);
    $a->setInfo("133班","12","23","47");
    $result = $a->setData();
    //print_r($a->getInfo());
    //echo '\n';
    print_r($result); 

$cls='1,2,3';
$a_cls=  explode(',', $cls);
if($a_cls[0] != NULL) {
    ?>
<html>
    <head>
        <title>test</title>
    </head>
    <body>
        <p>try this!</p>
    </body>
</html>
<?php
print_r($a_cls);
print_r($_SERVER["SCRIPT_NAME"]);
}
else {
    echo"nothing has in the array!";
}


include_once 'data.php';
require_once 'classes/Cclass.php';
header("Content-Type:text/html;charset=UTF-8");
global $DatabaseServer,$DatabaseUsername,$DatabasePassword,$DatabaseName;
$my_sqli = new mysqli($DatabaseServer,$DatabaseUsername,$DatabasePassword,$DatabaseName);
$my_sqli->set_charset("utf8");
$query = "SELECT * FROM `fellows` WHERE `fellow_id` = '1'";
$result = $my_sqli->query($query,MYSQLI_STORE_RESULT);
print_r($result->fetch_assoc());
 * 
print_r(phpinfo());
*/
error_reporting(E_ALL);
//require_once dirname(__FILE__).'/Locale.php';
//$lang = 'zh_TW';
//$Locale = new sit_Locale($lang);



?>  
<!DOCTYPE html>
<html>  

<head>  

<meta charset="UTF-8" />  
<link rel="stylesheet" href="styles.css">


<title>i18n</title>  

</head>  

<body bgcolor="#FFFFFF"  text= "#000000"  link= "#FF9966"  vlink= "#FF9966"  alink= "#FFCC99" >  
    
<?= gettext ( 'hello world.' ) ?>  
<?= _('welcome to i18n!') ?>
<?php
    $my_sqli = new mysqli($DatabaseServer,$DatabaseUsername,$DatabasePassword,$DatabaseName);
    $my_sqli->set_charset("utf8");
    $a = '1qaz2wsx';
    $b = 'root';
    echo "\n\t".crypt(md5($a),md5($b));
?>
    
</body>  

</html>
