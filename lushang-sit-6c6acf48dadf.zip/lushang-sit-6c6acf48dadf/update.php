<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
include_once 'header.php';
global $DatabaseServer,$DatabaseUsername,$DatabasePassword,$DatabaseName;

$class_id = $_SESSION['sess_class_id'];
$cls = new cClass($DatabaseServer, $DatabaseUsername, $DatabasePassword, $DatabaseName);
$class_name = $cls->getClassName($class_id);
$class_m = array_combine($class_id, $class_name);
?>


<script type="text/javascript">
$(document).ready(function(){
    
    $('#newTrackerButton').on('click',function(){
        var $btn = $(this).button('loading');
        $.ajax({
            type: "POST",
            url: "dbprocess.php",
            data: $("#newTracker").serialize(),
            success: function(msg) {
                alert(msg);
                location.reload();
            }
        });
        $btn.button('reset');
    });
});
</script>

<div class="container-fluid">
    <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
            <ul class="nav nav-sidebar">
                <?php
                    foreach ($class_m as $id => $name) {
                        echo "<li><a class='text-center' href='update.php?class_id=".$id."'>".$name."</a></li>";
                    }
                ?>
            </ul>
        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
            
<?php
if(isset($_GET["class_id"])) {
    $c_id = filter_input(INPUT_GET, "class_id");
    $c_name = $class_m[$c_id];
    $my_sqli = new mysqli($DatabaseServer,$DatabaseUsername,$DatabasePassword,$DatabaseName);
    $my_sqli->set_charset("utf8");
    $query = "SELECT `student_id`,`name` FROM `students` WHERE `class_id`=$c_id";
    $result = $my_sqli->query($query);
    //title of 
    echo "<h1 class='page-header'>"._('Update Tracker')."</h1>";
    if($result->num_rows == 0) {
        echo "<div class='alert alert-danger' role='alert'>"._("There is no student information in this class, please")." <a href='new.php?new_student'>"._("add students")."</a> first</div>";
    } else {
        ?>
            <form class="form-horizontal" role="form" id="newTracker" data-toggle="validator" method="post">
                <h3 class="sub-header"><?php echo _("Tracker information"); ?></h3>
                <input type="hidden" name="form" value="update_tracker">
                <input type="hidden" name="class_id" <?php echo "value='".$c_id."'"; ?>>
                <div class="form-group">
                    <label class="col-sm-1 control-label"><?php echo _('date') ?></label>
                    <div class="col-sm-3">
                        <input type="date" class="form-control" name="tracker_date" required="required">
                    </div>
                    <label class="col-sm-1 control-label"><?php echo _('type') ?></label>
                    <div class="col-sm-3">
                        <input type="text" class="form-control" name="tracker_type" required="required">
                    </div>
                    <label class="col-sm-2 control-label"><?php echo _('full mark') ?></label>
                    <div class="col-sm-2">
                        <input type="text" class="form-control" name="full_mark" required="required">
                    </div>
                </div>
                <h3 class="sub-header"><?php echo _('Student sorces'); ?></h3>
                <div class="form-group">
<?php
    $student_ids = '';
    while ($row = $result->fetch_assoc()) {
        echo "<label class='col-sm-2 control-label'>".$row["name"]."</label>";
        echo "<div class='col-sm-2'><input type='text' class='form-control' name='score_".$row["student_id"]."'></div>";
        $student_ids = $student_ids."_".$row["student_id"];
    }
    echo "</div>";
    echo "<input type='hidden' name='student_ids' value='".$student_ids."'>";
    $my_sqli->close();
?>
                <hr>
                <div class="form-group">
                    <div class="col-sm-6 col-sm-offset-6">
                        <button id="newTrackerButton" class="btn btn-default"><?php echo _('Update') ?></button>
                    </div>
                </div>
            </form>            
            
<?php
    }
}


echo "</div></div></div>";
include 'footer.php';
