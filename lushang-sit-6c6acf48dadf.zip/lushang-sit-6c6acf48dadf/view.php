<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
include_once 'header.php';
global $DatabaseServer,$DatabaseUsername,$DatabasePassword,$DatabaseName;

$class_id = $_SESSION['sess_class_id'];
$cls = new cClass($DatabaseServer, $DatabaseUsername, $DatabasePassword, $DatabaseName);
$class_name = $cls->getClassName($class_id);
$class_m = array_combine($class_id, $class_name);
?>

<script type="text/javascript" src="dist/js/d3.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    $("#add_note_form").submit(function(){return false;});
    $("#add").on("click", function(){
        //hide Add button
        $(this).hide("slow");
        //validation
        var dateval = $("#note_date").val();
        var noteval =$("#note").val();
        var notelen = noteval.length;
        //TODO: need a better way to valid the data
        var datevalid = validateDate(dateval);
        function validateDate(str){ 
            var pattern = /^(?:(?:(?:(?:1[6-9]|[2-9]\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00)))(\/|-|\.)(?:0?2\1(?:29))$)|(?:(?:1[6-9]|[2-9]\d)?\d{2})(\/|-|\.)(?:(?:(?:0?[13578]|1[02])\2(?:31))|(?:(?:0?[1,3-9]|1[0-2])\2(29|30))|(?:(?:0?[1-9])|(?:1[0-2]))\2(?:0?[1-9]|1\d|2[0-8]))$/;
            return pattern.test(str);
        }
        if(datevalid === false) {
            $("#note_date").addClass("error");
        }else if(datevalid === true){ 
            $("#note_date").removeClass("error"); 
        } 

        if(notelen < 4) { 
            $("#note").addClass("error"); 
        } else if(notelen >= 4){ 
            $("#note").removeClass("error"); 
        }
        $.ajax({ 
        type: "POST", 
        url: "dprocess.php", 
        data: $("#add_note_form").serialize(), 
        success: function(data) {
            if(data === "false") { 
                $("#add_note_form").fadeOut("fast", function(){ 
                    $(this).before("<div class='alert alert-danger' role='alert'><strong><?php echo _("ERROR: The note has not been updated.");?></strong></div>"); 
                    setTimeout("$('#addNote').modal('hide')", 4000); 
                }); 
            } else {
                //only refreash the note Table(add the new note)
                var notemeta = data.getElementsByTagName("notemeta")[0];
                var date = notemeta.getElementsByTagName("date")[0];
                var note = notemeta.getElementsByTagName("note")[0];
                var noteTable = document.getElementById("student_note");
                var row = document.createElement("tr");
                var cell1 = document.createElement("td");
                cell1.appendChild(document.createTextNode(date.childNodes[0].nodeValue));
                row.appendChild(cell1);
                var cell2 = document.createElement("td");
                cell2.appendChild(document.createTextNode(note.childNodes[0].nodeValue));
                row.appendChild(cell2);
                noteTable.appendChild(row);
                $("#add_note_form").fadeOut("fast", function(){ 
                    $(this).before("<div class='alert alert-success' role='alert'><strong><?php echo _("The note has been updated. If you want to add another note, please refresh the page.");?></strong></div>"); 
                    setTimeout("$('#addNote').modal('hide')", 4000); 
                });
            }
        }  
    });
    });
});
</script>
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
            <ul class="nav nav-sidebar">
                <?php
                    foreach ($class_m as $id => $name) {
                        echo "<li><a class='text-center' href='view.php?class_id=".$id."'>".$name."</a></li>";
                    }
                ?>
            </ul>
        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
<?php
// show the information(tracker) of one class choosed
if(isset($_GET["class_id"])) {
    $c_id = filter_input(INPUT_GET, "class_id"); //class id
    $c_name = $class_m[$c_id]; //class name
    //statistics use tracker data directly
    echo "<h1 class='page-header'>"._('Tracker of the class ')."$c_name"."</h1>";
    $my_sqli = new mysqli($DatabaseServer,$DatabaseUsername,$DatabasePassword,$DatabaseName);
    $my_sqli->set_charset("utf8");
    $query = "SELECT `tracker_id`,  `tracker_date`, `tracker_type`, `full_mark`, `average`, `max`, `min`, `passrate`, `excellent_rate` FROM `tracker` WHERE `class_id`=$c_id";
    $result = $my_sqli->query($query);
    $tracker_info = array(); //define tracker infomation array;
    $tracker_num = $result->num_rows;
    // if no data fetched, the alert with a link to create a tracker
    if($tracker_num == 0) {
        echo "<div class='alert alert-danger' role='alert'>"
            ._("There is no tracker information in this class, please")
                ." <a class='alert-link' href='update.php?class_id=$c_id'>"._("update tracker")."</a> first</div>";
    } else {
        $tracker_index = 1;
        while ($row = $result->fetch_assoc()) {
            $row['tracker_index'] = $tracker_index;
            //array_push($tracker_info, $row);
            $tracker_info[] = $row; //to be high efficiency, to avoid function call of array_push
            $tracker_index = $tracker_index + 1;
        }
        echo "<table class='table table-hover'><tr><th>Date</th>";
        for ($index = 0; $index < $tracker_num; $index++) {
            print_r("<td>".$tracker_info[$index]['tracker_date']."</td>") ;
        }
        echo"</tr><tr><th>Type</th>";
         for ($index = 0; $index < $tracker_num; $index++) {
            print_r("<td>".$tracker_info[$index]['tracker_type']."</td>") ;
        }
        echo"</tr><tr><th>"._("Full mark")."</th>";
         for ($index = 0; $index < $tracker_num; $index++) {
            print_r("<td>".$tracker_info[$index]['full_mark']."</td>") ;
        }
        echo"</tr><tr><th>"._("Average")."</th>";
         for ($index = 0; $index < $tracker_num; $index++) {
            printf("<td>%.3f</td>", $tracker_info[$index]['average']);
        }
        echo"</tr><tr><th>"._("Max")."</th>";
         for ($index = 0; $index < $tracker_num; $index++) {
            print_r("<td>".$tracker_info[$index]['max']."</td>") ;
        }
        echo"</tr><tr><th>"._("Min")."</th>";
         for ($index = 0; $index < $tracker_num; $index++) {
            print_r("<td>".$tracker_info[$index]['min']."</td>") ;
        }
        echo"</tr><tr><th>"._("Passrate")."</th>";
         for ($index = 0; $index < $tracker_num; $index++) {
            printf("<td>%.2f%%</td>", $tracker_info[$index]['passrate']*100);
        }
        echo"</tr><tr><th>"._("Excellent rate")."</th>";
         for ($index = 0; $index < $tracker_num; $index++) {
            printf("<td>%.2f%%</td>", $tracker_info[$index]['excellent_rate']*100);
        }
        echo "</tr><tr><th colspan='".($tracker_num+1)."'>"._("Student score")."</th>";
        $query = "SELECT `student_id`,  `name` FROM `students` WHERE `class_id`=$c_id";
        $result = $my_sqli->query($query);
        while ($row = $result->fetch_assoc()) {
            echo "</tr><tr><th><a href='view.php?student_id=".$row["student_id"]."'>".$row["name"]."</a></th>";
            $query = "SELECT  `score`,`tracker_id` FROM `student_tracker` WHERE `student_id`=".$row['student_id'];
            $result_t = $my_sqli->query($query);
            while($row_t = $result_t->fetch_assoc()) {
                printf("<td>%s</td>",$row_t['score']);
            }
        }

        echo"</tr></table>";
        echo "<h3 class='sub-header'>"._("Score line chart of the class")."</h3>";
        ?>
        <div id='classScoreLC'></div>
        <script type="text/javascript" src="dist/js/classScoreLineChart.js"></script>'
        <script type="text/javascript">
            //var trackerInfo = {"trackers":<?php echo json_encode($tracker_info); ?>};
            var trackerInfoJSON = <?php echo json_encode($tracker_info); ?>;
            drawScoreLineChart(trackerInfoJSON,'');
            //alert(trackerInfo.trackers[3].tracker_date);
        </script>
        <?php
        //echo json_encode($tracker_info);

    }
}

if(isset($_GET["student_id"])) {
    $student_id = filter_input(INPUT_GET, "student_id");
    $student = new Student($DatabaseServer, $DatabaseUsername, $DatabasePassword, $DatabaseName, $student_id);
    $student->getData();
    $student_info = $student->getInfo();
    //Shows the basic information of the student
    echo "<h1 class='page-header'>"._("Student basic information")."</h1>";
    echo "<table class='table table-hover'><tr><th>"._("Name")."</th><th>"._("Gender")."</th><th>"._("Nationality")."</th>";
    echo "</tr><tr><td>".$student_info['name']."</td><td>".$student_info['gender']."</td><td>".$student_info['nationality']."</td>";
    echo "</tr><tr><th>"._("Birthday")."</th><th>"._("Phone")."</th><th>"._("Address")."</th>";
    echo "</tr><tr><td>".$student_info['birthday']."</td><td>".$student_info['phone']."</td><td>".$student_info['address']."</td>";
    echo '</tr></table>';
    ?>
    <!-- shows Notes about the student -->
    <h3 class="sub-header"> <?php echo _("Student Note ") ?>
        <small><a  data-toggle="modal" data-target="#addNote" href="#addNote"><?php echo _("Add note") ?></a></small>
        <button type="button" class="btn" data-toggle="collapse" data-target="#student_note">
                Click to collapse the rows
              </button>
    </h3>
    <!-- modal form -->
    <div class="modal fade" id="addNote" tabindex="-1" role="dialog" aria-labelledby="addNoteLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                    <h4 class="modal-title" id="myModalLabel"><?php echo _("And note for ").$student_info['name'];?></h4>
                </div>
                <div class="modal-body">
                    <form class="form-horizontal" role="form" id="add_note_form" method="post">
                        <input type="hidden" name="form" value="add_note">
                        <input type="hidden" name="student_id" <?php echo "value='".$student_id."'";?>>
                        <div class="form-group">
                            <label for="inputDate" class="col-sm-2 control-label"> <?php echo _("Date");?> </label>
                            <div class="col-sm-10">
                                <input class="form-control" id="note_date" name="date" type="date" <?php echo "value='".date('Y-m-d')."'";?>/>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="note" class="col-sm-2 control-label"><?php echo _("Note");?></label>
                            <div class="col-sm-10">
                                <textarea id="note" class="form-control" name="note"></textarea>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo _("Close")?></button>
                    <button id="add" type="button" class="btn btn-primary"><?php echo _("Add")?></button>
                </div>
            </div>
        </div>
    </div>
    <?php
    echo "<table id='student_note' class='table table-hover collapse in'><tr><th>"._("Date")."</th><th>"._("Note")."</th></tr>";
    $notes = explode("##note8888##", $student_info['note']);
    foreach ($notes as $note) {
        $notem = explode("##time8888##", $note);
        echo "<tr><td>$notem[0]</td><td>$notem[1]</td></tr>";
    }
    // Tracker of AA
    echo "</table><h3 class='sub-header'>"._("Track of AA")."</h3>";
    echo "<table class='table table-hover'><tr><th>"._('Date')."</th><th>"._('Type')."</th><th>"._('Full mark')."</th><th>"._('Average')."</th><th>"._('Score')."</th></tr>";
    $my_sqli = new mysqli($DatabaseServer,$DatabaseUsername,$DatabasePassword,$DatabaseName);
    $my_sqli->set_charset("utf8");
    $query = "SELECT  `tracker_id`, `score` FROM `student_tracker` WHERE `student_id`=$student_id";
    $result = $my_sqli->query($query);
    $tracker_infos = array(); // for the use of visualization of the tracker
    $tracker_index = 1; // index of the tracker as 1,2,3,4....
    while($row = $result->fetch_assoc()) {
        $score = $row['score'];
        $tracker_id = $row['tracker_id'];
        $query_t = "SELECT `tracker_date`, `tracker_type`, `full_mark`, `average` FROM `tracker` WHERE `tracker_id`=$tracker_id";
        $rst = $my_sqli->query($query_t);
        $tracker_info = $rst->fetch_assoc();
        echo "<tr><td>".$tracker_info['tracker_date']."</td><td>".$tracker_info['tracker_type']."</td><td>".$tracker_info['full_mark']."</td><td>".$tracker_info['average']."</td><td>$score</td></tr>";
        $tracker_info['tracker_id'] = $tracker_id; // add tracker id to tracker info
        $tracker_info['score'] = $score; // add score to tracker info
        $tracker_info['tracker_index'] = $tracker_index;
        $tracker_infos[] = $tracker_info; // add tracker info to tracker information
        $tracker_index = $tracker_index + 1;
    }
    echo "</table>";
    echo "<h3 class='sub-header'>"._("Score line chart of the student")."</h3>";
    ?>
            <div id='classScoreLC'></div>
            <script type="text/javascript" src="dist/js/classScoreLineChart.js"></script>'
            <script type="text/javascript">
                var trackerInfoJSON = <?php echo json_encode($tracker_infos); ?>;
                drawScoreLineChart(trackerInfoJSON, 'student');
                //alert(trackerInfo.trackers[3].tracker_date);
            </script>
        <?php
        //echo json_encode($tracker_infos);
}
echo "</div></div></div>";

include 'footer.php';